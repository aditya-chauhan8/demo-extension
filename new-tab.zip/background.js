console.log("Background.js called");
var completeUrl;
var urlProtocol;
var httpStatusCode;
var responseStatus;


// chrome.webNavigation.onDOMContentLoaded.addListener(function (details) {
//   chrome.storage.local.get(['debuggerAttached', 'lastNavigationId'], function (result) {
//     const currentNavigationId = details.navigationId || details.frameId;

//     if (result.debuggerAttached && result.lastNavigationId === currentNavigationId) {
//       return;
//     }

//     const detachDebugger = () => {
//       chrome.debugger.detach({ tabId: details.tabId }, function () {
//         console.log("Debugger detached");
//       });
//       chrome.debugger.onEvent.removeListener(onEventCallback);
//       chrome.storage.local.remove(['debuggerAttached', 'lastNavigationId']);
//     };

//     const onEventCallback = function (debuggeeId, message, params) {
//       if (message == "Network.responseReceived") {
//         console.log("Page loaded with status code:", params.response.status);
//         statusCode = params.response.status;
//         detachDebugger();
//       }
//     };

//     chrome.storage.local.set({ debuggerAttached: true, lastNavigationId: currentNavigationId });

//     chrome.debugger.attach({ tabId: details.tabId }, "1.2", function () {
//       chrome.debugger.sendCommand({ tabId: details.tabId }, "Network.enable", {}, function () {
//         chrome.debugger.onEvent.addListener(onEventCallback);
//       });
//     });
//   });
// }, { url: [{ schemes: ["http", "https"] }] });


  
// Get the extension manifest
const manifest = chrome.runtime.getManifest();
const deviceToken = manifest.storage.device_token;
console.log('Extension Description:', deviceToken);
chrome.storage.local.set({ 'device_token': deviceToken });  
  
  
  
// Listen for messages from content.js
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    // Log the received values
    console.log('Received Complete URL:', request.completeUrl);
    console.log('Received Complete URL:', request.urlProtocol);
    console.log('Received Complete URL:', request.statusCode);

    completeUrl = request.completeUrl;
    urlProtocol = request.urlProtocol;
    httpStatusCode = request.statusCode;
    // You can perform further actions with the received values here
    console.log(completeUrl, urlProtocol, httpStatusCode);


    if (httpStatusCode === 404) {
      responseStatus = 4;
      console.log('It is not a valid URL or IP address.', responseStatus);
    } else if (isIpAddress(request.completeUrl)) {
      responseStatus = 3;
      console.log('It is an IP address.', responseStatus);
    } else if (urlProtocol === 'http:'){
      responseStatus = 2;
      console.log('Url is not secure.', responseStatus);
    } else {
      responseStatus = 1;
      console.log('Url is secure.', responseStatus);
    }

    saveVisitedUrls(completeUrl, responseStatus);
  }
);



// Function to check if a string is a valid IP address
function isIpAddress(input) {
  // Regular expression for matching an IP address
  const ipRegex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  return ipRegex.test(input);
}

// // Function to check if a string is a normal URL
// function isNormalUrl(input) {
//   // Regular expression for matching a normal URL
//   const urlRegex = /^(?:(?:https?|ftp):\/\/)?(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z]{2,})+(?:\/[^\s]*)?$/;
//   return urlRegex.test(input);
// }

function saveVisitedUrls (completeUrl, responseStatus){
  console.log(completeUrl, responseStatus,deviceToken);

  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");

  var raw = JSON.stringify({
    "device_token": deviceToken,
    "url": completeUrl,
    "status": responseStatus
  });

  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
    redirect: 'follow'
  };

  fetch("https://thesimplewebaddition.com/wp-json/api/v1/save_visited_url", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));


}